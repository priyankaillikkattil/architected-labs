Steps to Follow

1. Install Docker desktop
2. Open cmd and navigate to the current folder
3. Run 'docker-compose up --build'
4. Clone auth from GitLab in the same folder
5. copy files-to-copy/* and paste into the root folder

6. Go to localhost:8100 and check whether Nginx is working

7. If no errors, Open PHPstorm and connect to the database with the following details
   
   Port - 3309
   user - root
   password - password
   db name - thecloud_auth


